# Faça login no Azure
az login

# Selecione a subscription correta
az account set --subscription "<SeuSubscriptionID>"

# Crie um Resource Group
az group create --name "<SeuResourceGroupName>" --location "<SeuLocation>"

# Crie uma Function App
az functionapp create --resource-group "<SeuResourceGroupName>" --consumption-plan-location "<SeuLocation>" --runtime dotnet --functions-version 3 --name "<NomeDoSeuFunctionApp>" --storage-account "<NomeDaSuaStorageAccount>"

# Publique a função
func azure functionapp publish <NomeDoSeuFunctionApp>
